from flask import Flask, render_template, request, redirect, session, url_for

import sqlite3

app = Flask(__name__)
app.secret_key = "supersecret"
def get_db():
    conn = sqlite3.connect("skill_swap.db")
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        location = request.form['location']
        availability = request.form['availability']
        is_public = 1 if 'is_public' in request.form else 0

        conn = get_db()
        conn.execute("INSERT INTO users (name, location, availability, is_public) VALUES (?, ?, ?, ?)",
                     (name, location, availability, is_public))
        conn.commit()
        conn.close()
        return redirect('/login')
    return render_template("register.html")

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        name = request.form['name']
        location = request.form['location']
        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE name = ? and location = ?", (name,location)).fetchone()
        if user:
            session['user_id'] = user['id']
            session['username'] = user['name']
            return redirect('/dashboard')
        return "User not found!"
    return render_template("login.html")

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect('/login')
    return render_template("dashboard.html", username=session['username'])

@app.route('/browse')
def browse_users():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = get_db()
    users = conn.execute("""
        SELECT * FROM users
        WHERE id != ? AND is_public = 1
    """, (session['user_id'],)).fetchall()

    skills = conn.execute("""
        SELECT * FROM skills_offered
    """).fetchall()

    return render_template('browse.html', users=users, skills=skills)

    
@app.route('/add_skills', methods=['GET', 'POST'])
def add_skills():
    if 'user_id' not in session:
        return redirect('/login')

    if request.method == 'POST':
        offered = request.form.get('offered_skill')
        wanted = request.form.get('wanted_skill')
        user_id = session['user_id']
        conn = get_db()
        if offered:
            conn.execute("INSERT INTO skills_offered (user_id, skill_name) VALUES (?, ?)", (user_id, offered))
        if wanted:
            conn.execute("INSERT INTO skills_wanted (user_id, skill_name) VALUES (?, ?)", (user_id, wanted))
        conn.commit()
        conn.close()
        return redirect('/dashboard')
    return render_template("add_skill.html")

# View All Skills
@app.route('/search', methods=['GET', 'POST'])
def search():
    if request.method == 'POST':
        skill = request.form['skill']
        conn = get_db()
        results = conn.execute("""
            SELECT u.name, u.location, s.skill_name FROM users u
            JOIN skills_offered s ON u.id = s.user_id
            WHERE s.skill_name LIKE ? AND u.is_public = 1
        """, ('%' + skill + '%',)).fetchall()
        return render_template("search.html", results=results, searched=skill)
    return render_template("search.html", results=None)

@app.route('/request_swap/<int:to_user>', methods=['GET', 'POST'])
def request_swap(to_user):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = get_db()
    target_user = conn.execute("SELECT * FROM users WHERE id = ?", (to_user,)).fetchone()

    if request.method == 'POST':
        from_user = session['user_id']
        offered_skill = request.form['offered_skill']
        wanted_skill = request.form['wanted_skill']
        message = request.form['message']

        conn.execute("""
            INSERT INTO swap_requests (sender_id, receiver_id, skill_offered, skill_requested , status, message)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (from_user, to_user, offered_skill, wanted_skill, "pending", message))
        conn.commit()
        return redirect(url_for('dashboard'))

    return render_template('request_swap.html', target_user=target_user)

    
@app.route('/my_swaps')
def my_swaps():
    if 'user_id' not in session:
        return redirect('/login')

    uid = session['user_id']
    conn = get_db()
    sent = conn.execute("""
    SELECT s.id, u.name AS receiver_name, s.skill_offered, s.skill_requested , s.message, s.status
    FROM swap_requests s
    JOIN users u ON s.receiver_id = u.id
    WHERE s.sender_id = ?


    """, (uid,)).fetchall()

    received = conn.execute("""
        SELECT s.id, u.name AS sender_name, s.skill_offered, s.skill_requested , s.status
        FROM swap_requests s
        JOIN users u ON s.sender_id = u.id
        WHERE s.receiver_id = ?
    """, (uid,)).fetchall()

    return render_template("my_swaps.html", sent=sent, received=received)
    
@app.route('/respond_swap', methods=['POST'])
def respond_swap():
    req_id = request.form['request_id']
    action = request.form['action']

    new_status = 'accepted' if action == 'accept' else 'rejected'

    conn = get_db()
    conn.execute("UPDATE swap_requests SET status = ? WHERE id = ?", (new_status, req_id))
    conn.commit()

    return redirect('/my_swaps')

@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_db()
        admin = conn.execute("SELECT * FROM admins WHERE username = ? AND password = ?", (username, password)).fetchone()
        conn.close()

        if admin:
            session['admin_id'] = admin['id']
            return redirect('/admin_dashboard')
        return "Invalid credentials!"
    return render_template('admin_login.html')

@app.route('/admin_dashboard')
def admin_dashboard():
    if 'admin_id' not in session:
        return redirect('/admin_login')

    conn = get_db()
    swaps = conn.execute("SELECT * FROM swap_requests").fetchall()
    users = conn.execute("SELECT * FROM users").fetchall()
    return render_template("admin_dashboard.html", swaps=swaps, users=users)

@app.route('/moderate_skills')
def moderate_skills():
    if 'admin_id' not in session:
        return redirect('/admin_login')

    conn = get_db()

    # Join to get offered skills with user names
    offered = conn.execute("""
        SELECT skills_offered.id, skills_offered.skill_name, skills_offered.user_id, users.name AS user_name
        FROM skills_offered
        JOIN users ON skills_offered.user_id = users.id
    """).fetchall()

    # Join to get wanted skills with user names
    wanted = conn.execute("""
        SELECT skills_wanted.id, skills_wanted.skill_name, skills_wanted.user_id, users.name AS user_name
        FROM skills_wanted
        JOIN users ON skills_wanted.user_id = users.id
    """).fetchall()

    return render_template("moderate_skills.html", offered=offered, wanted=wanted)


@app.route('/approve_skill/<int:skill_id>/<string:skill_type>')
def approve_skill(skill_id, skill_type):
    if 'admin_id' not in session:
        return redirect('/admin_login')

    conn = get_db()
    table = 'skills_offered' if skill_type == 'offered' else 'skills_wanted'
    conn.execute(f"UPDATE {table} SET approved = 1 WHERE id = ?", (skill_id,))
    conn.commit()
    return redirect('/moderate_skills')

@app.route('/reject_skill/<int:skill_id>/<string:skill_type>')
def reject_skill(skill_id, skill_type):
    if 'admin_id' not in session:
        return redirect('/admin_login')

    conn = get_db()
    table = 'skills_offered' if skill_type == 'offered' else 'skills_wanted'
    conn.execute(f"DELETE FROM {table} WHERE id = ?", (skill_id,))
    conn.commit()
    return redirect('/moderate_skills')

@app.route('/ban_user/<int:user_id>')
def ban_user(user_id):
    if 'admin_id' not in session:
        return redirect('/admin_login')
    conn = get_db()
    conn.execute("UPDATE users SET banned = 1 WHERE id = ?", (user_id,))
    conn.commit()
    return redirect('/admin_dashboard')

@app.route('/unban_user/<int:user_id>')
def unban_user(user_id):
    if 'admin_id' not in session:
        return redirect('/admin_login')
    conn = get_db()
    conn.execute("UPDATE users SET banned = 0 WHERE id = ?", (user_id,))
    conn.commit()
    return redirect('/admin_dashboard')

@app.route('/send_announcement', methods=['GET', 'POST'])
def send_announcement():
    if 'admin_id' not in session:
        return redirect('/admin_login')

    if request.method == 'POST':
        msg = request.form['message']
        conn = get_db()
        conn.execute("INSERT INTO announcements (message) VALUES (?)", (msg,))
        conn.commit()
        return redirect('/admin_dashboard')
    return render_template("send_announcement.html")

if __name__ == '__main__':
    app.run(debug=True)
