import sqlite3
from database import create_tables

current_user = None

def register():
    conn = sqlite3.connect("skill_swap.db")
    cursor = conn.cursor()

    name = input("Name: ")
    location = input("Location (optional): ")
    photo = input("Profile photo filename (optional): ")
    availability = input("Availability (e.g. evenings): ")
    is_public = input("Make profile public? (yes/no): ").lower() == "yes"

    cursor.execute("INSERT INTO users (name, location, profile_photo, availability, is_public) VALUES (?, ?, ?, ?, ?)",
                   (name, location, photo, availability, is_public))
    conn.commit()
    conn.close()
    print("✅ Registered successfully!\n")

def login():
    global current_user
    name = input("Enter your name to login: ")
    conn = sqlite3.connect("skill_swap.db")
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users WHERE name = ?", (name,))
    user = cursor.fetchone()

    if user:
        current_user = user
        print(f"✅ Welcome, {user[1]}!")
    else:
        print("❌ User not found.")

def user_menu():
    print("""
--- Skill Swap Platform ---
1. Register
2. Login
3. Exit
""")
    choice = input("Enter choice: ")
    if choice == "1":
        register()
    elif choice == "2":
        login()
    elif choice == "3":
        print("Goodbye!")
        exit()
    else:
        print("Invalid choice.")

def main():
    create_tables()
    while True:
        user_menu()

if __name__ == "__main__":
    main()
