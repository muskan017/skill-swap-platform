import sqlite3

def create_tables():
    
    conn = sqlite3.connect("skill_swap.db")
    cursor = conn.cursor()

    # Users
    cursor.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        location TEXT,
        profile_photo TEXT,
        availability TEXT,
        is_public BOOLEAN DEFAULT 1,
        is_banned BOOLEAN DEFAULT 0
    )""")

    # Skills offered
    cursor.execute("""CREATE TABLE IF NOT EXISTS skills_offered (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        skill_name TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )""")

    # Skills wanted
    cursor.execute("""CREATE TABLE IF NOT EXISTS skills_wanted (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        skill_name TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )""")

    # Swap Requests
    cursor.execute("""CREATE TABLE IF NOT EXISTS swap_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sender_id INTEGER,
        receiver_id INTEGER,
        skill TEXT,
        status TEXT DEFAULT 'pending',
        FOREIGN KEY (sender_id) REFERENCES users(id),
        FOREIGN KEY (receiver_id) REFERENCES users(id)
    )""")

    # Ratings
    cursor.execute("""CREATE TABLE IF NOT EXISTS ratings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        swap_id INTEGER,
        from_user_id INTEGER,
        to_user_id INTEGER,
        rating INTEGER,
        feedback TEXT,
        FOREIGN KEY (swap_id) REFERENCES swap_requests(id)
    )""")

    # Admins
    cursor.execute("""CREATE TABLE IF NOT EXISTS admins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        password TEXT NOT NULL
    )""")

    conn.commit()
    conn.close()
create_tables()
